package io.crudcursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
